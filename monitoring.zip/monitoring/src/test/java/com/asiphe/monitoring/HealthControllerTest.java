package com.asiphe.monitoring;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
public class HealthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void homeEndpointShouldReturnRunningStatus() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.application").value("Hashe Continous Monitoring"))
                .andExpect(jsonPath("$.status").value("running"));
    }

    @Test
    void testEndpointShouldReturnSuccess() throws Exception {

        mockMvc.perform(get("/api/test"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Application logging is working"))
                .andExpect(jsonPath("$.status").value("success"));
    }

    @Test
    void errorTestEndpointSouldReturnWarning() throws Exception {

        mockMvc.perform(get("/api/error-test"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Test warning generated"))
                .andExpect(jsonPath("$.status").value("warning"));
    }

    @Test
    void healthEndpointShouldreturnUp() throws Exception {

        mockMvc.perform(get("/actuator/health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("UP"));
    }

}
