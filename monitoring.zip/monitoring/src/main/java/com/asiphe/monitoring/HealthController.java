package com.asiphe.monitoring;

import java.time.Instant;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController 
public class HealthController {

    public static final Logger logger = LoggerFactory.getLogger(HealthController.class);

    @GetMapping("/")
    public Map<String, String> home(){

        logger.info("Home endpoint accessed");

        return Map.of(
            "application", "Hashe Continous Monitoring",
            "status", "running",
            "timestamp", Instant.now().toString()
        );
    }

    @GetMapping("/api/test")
    public Map<String, String> test(){

        logger.info("Test endpoint accessed successfully");

        return Map.of(
            "message", "Application logging is working fine",
            "status", "success"
        );
    }

    @GetMapping("/api/error-test")
    public Map<String, String> errorTest(){

        logger.warn("Test warning generated for monitoring verification");

        return Map.of(
            "message", "Test warning generated",
            "status", "warning"
        );
    }

}
